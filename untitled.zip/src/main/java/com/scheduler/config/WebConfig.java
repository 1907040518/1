package com.scheduler.config;

public class WebConfig {
}
