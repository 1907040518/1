package com.scheduler.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.quartz.QuartzProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
public class QuartzConfig {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private QuartzProperties quartzProperties;

    @Value("${spring.quartz.properties.org.quartz.jobStore.tablePrefix:QRTZ_}")
    private String tablePrefix;

    @Value("${spring.quartz.properties.org.quartz.jobStore.isClustered:false}")
    private String isClustered;

    @Value("${spring.quartz.properties.org.quartz.threadPool.threadCount:10}")
    private String threadCount;

    @Value("${org.quartz.dataSource.quartzDS.URL:#{null}}")
    private String dataSourceURL;

    @Bean
    public SchedulerFactoryBean schedulerFactoryBean() {
        SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();

        // 设置AutowiringSpringBeanJobFactory
        AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
        jobFactory.setApplicationContext(applicationContext);
        schedulerFactoryBean.setJobFactory(jobFactory);

        // 设置数据源
        schedulerFactoryBean.setDataSource(dataSource);

        // 设置Quartz属性
        schedulerFactoryBean.setQuartzProperties(getQuartzProperties());

        // 设置覆盖已存在的jobs
        schedulerFactoryBean.setOverwriteExistingJobs(true);

        // 设置应用上下文调度器上下文关键字
        schedulerFactoryBean.setApplicationContextSchedulerContextKey("applicationContext");

        // 延时启动
        schedulerFactoryBean.setStartupDelay(10);

        // 自动启动
        schedulerFactoryBean.setAutoStartup(true);

        return schedulerFactoryBean;
    }

    private Properties getQuartzProperties() {
        Properties props = new Properties();

        // 调度器属性
        props.put("org.quartz.scheduler.instanceName", "QuartzClusteredScheduler");
        props.put("org.quartz.scheduler.instanceId", "AUTO");

        // 线程池属性
        props.put("org.quartz.threadPool.class", "org.quartz.simpl.SimpleThreadPool");
        props.put("org.quartz.threadPool.threadCount", threadCount);
        props.put("org.quartz.threadPool.threadPriority", "5");

        // JobStore属性
        props.put("org.quartz.jobStore.class", "org.quartz.impl.jdbcjobstore.JobStoreTX");
        props.put("org.quartz.jobStore.driverDelegateClass", "org.quartz.impl.jdbcjobstore.StdJDBCDelegate");
        props.put("org.quartz.jobStore.useProperties", "false");
        props.put("org.quartz.jobStore.tablePrefix", tablePrefix);
        props.put("org.quartz.jobStore.isClustered", isClustered);
        props.put("org.quartz.jobStore.clusterCheckinInterval", "20000");
        props.put("org.quartz.jobStore.misfireThreshold", "60000");
        props.put("org.quartz.jobStore.dataSource", "quartzDS");

        // 配置数据源
        props.put("org.quartz.dataSource.quartzDS.provider", "hikaricp");
        props.put("org.quartz.dataSource.quartzDS.driver", "com.mysql.cj.jdbc.Driver");

        // 如果提供了自定义URL，使用它，否则使用默认URL
        if (dataSourceURL != null && !dataSourceURL.isEmpty()) {
            props.put("org.quartz.dataSource.quartzDS.URL", dataSourceURL);
        } else {
            props.put("org.quartz.dataSource.quartzDS.URL", "jdbc:mysql://localhost:3306/quartz_demo?useSSL=false&serverTimezone=UTC");
        }

        props.put("org.quartz.dataSource.quartzDS.user", "root");
        props.put("org.quartz.dataSource.quartzDS.password", "123456");
        props.put("org.quartz.dataSource.quartzDS.maxConnections", "10");

        return props;
    }
}