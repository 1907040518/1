package com.scheduler.service;

import com.scheduler.model.JobInfo;
import com.scheduler.model.JobResponse;

import java.util.List;
import java.util.Map;

public interface JobService {

    // 创建并调度一个新作业
    JobResponse scheduleJob(JobInfo jobInfo) throws Exception;

    // 使用Cron表达式调度作业
    JobResponse scheduleJobWithCron(String jobName, String jobGroup, Class<?> jobClass,
                                    String cronExpression, Map<String, Object> jobData) throws Exception;

    // 使用简单调度创建作业
    JobResponse scheduleJobWithSimpleTrigger(String jobName, String jobGroup, Class<?> jobClass,
                                             int repeatCount, long repeatInterval,
                                             Map<String, Object> jobData) throws Exception;

    // 暂停作业
    JobResponse pauseJob(String jobName, String jobGroup) throws Exception;

    // 恢复作业
    JobResponse resumeJob(String jobName, String jobGroup) throws Exception;

    // 更新作业定时规则
    JobResponse updateJobSchedule(String jobName, String jobGroup, String cronExpression) throws Exception;

    // 删除作业
    JobResponse deleteJob(String jobName, String jobGroup) throws Exception;

    // 获取所有作业信息
    List<JobResponse> getAllJobs() throws Exception;

    // 获取指定作业信息
    JobResponse getJobDetail(String jobName, String jobGroup) throws Exception;

    // 立即触发一次作业执行
    JobResponse triggerJobNow(String jobName, String jobGroup) throws Exception;

    // 更新作业数据
    JobResponse updateJobData(String jobName, String jobGroup, Map<String, Object> jobData) throws Exception;
}