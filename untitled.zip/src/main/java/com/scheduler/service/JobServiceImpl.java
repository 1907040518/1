package com.scheduler.service;

import com.scheduler.model.JobInfo;
import com.scheduler.model.JobResponse;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class JobServiceImpl implements JobService {

    @Autowired
    private Scheduler scheduler;

    @Override
    public JobResponse scheduleJob(JobInfo jobInfo) throws Exception {
        try {
            if (scheduler.checkExists(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()))) {
                throw new Exception("Job already exists");
            }

            // 创建JobDetail
            Class<? extends Job> jobClass = (Class<? extends Job>) Class.forName(jobInfo.getJobClass());
            JobDetail jobDetail = buildJobDetail(jobInfo.getJobName(), jobInfo.getJobGroup(),
                    jobClass, jobInfo.getDescription(), jobInfo.getJobData(), jobInfo.isDurability());

            // 创建触发器
            Trigger trigger;
            if ("CRON".equalsIgnoreCase(jobInfo.getScheduleType())) {
                trigger = buildCronTrigger(jobInfo.getJobName(), jobInfo.getJobGroup(), jobInfo.getCronExpression());
            } else {
                trigger = buildSimpleTrigger(jobInfo.getJobName(), jobInfo.getJobGroup(),
                        jobInfo.getRepeatCount(), jobInfo.getRepeatInterval(), jobInfo.getStartDelay());
            }

            // 调度作业
            Date firstFireTime = scheduler.scheduleJob(jobDetail, trigger);

            log.info("Job scheduled: {} in group {}, first fire time: {}",
                    jobInfo.getJobName(), jobInfo.getJobGroup(), firstFireTime);

            return buildJobResponse(jobDetail.getKey(), Trigger.TriggerState.NORMAL.name(),
                    "Job scheduled successfully", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error scheduling job: ", e);
            throw new Exception("Failed to schedule job: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse scheduleJobWithCron(String jobName, String jobGroup, Class<?> jobClass,
                                           String cronExpression, Map<String, Object> jobData) throws Exception {
        try {
            // 创建JobDetail
            JobDetail jobDetail = buildJobDetail(jobName, jobGroup, (Class<? extends Job>)jobClass,
                    "Job scheduled with cron: " + cronExpression, jobData, true);

            // 创建Cron触发器
            Trigger trigger = buildCronTrigger(jobName, jobGroup, cronExpression);

            // 调度作业
            Date firstFireTime = scheduler.scheduleJob(jobDetail, trigger);

            log.info("Job scheduled with cron: {} in group {}, first fire time: {}",
                    jobName, jobGroup, firstFireTime);

            return buildJobResponse(jobDetail.getKey(), Trigger.TriggerState.NORMAL.name(),
                    "Job scheduled with cron expression", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error scheduling job with cron: ", e);
            throw new Exception("Failed to schedule job with cron: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse scheduleJobWithSimpleTrigger(String jobName, String jobGroup, Class<?> jobClass,
                                                    int repeatCount, long repeatInterval,
                                                    Map<String, Object> jobData) throws Exception {
        try {
            // 创建JobDetail
            JobDetail jobDetail = buildJobDetail(jobName, jobGroup, (Class<? extends Job>)jobClass,
                    "Job scheduled with simple trigger", jobData, true);

            // 创建简单触发器
            Trigger trigger = buildSimpleTrigger(jobName, jobGroup, repeatCount, repeatInterval, 0);

            // 调度作业
            Date firstFireTime = scheduler.scheduleJob(jobDetail, trigger);

            log.info("Job scheduled with simple trigger: {} in group {}, first fire time: {}",
                    jobName, jobGroup, firstFireTime);

            return buildJobResponse(jobDetail.getKey(), Trigger.TriggerState.NORMAL.name(),
                    "Job scheduled with simple trigger", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error scheduling job with simple trigger: ", e);
            throw new Exception("Failed to schedule job with simple trigger: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse pauseJob(String jobName, String jobGroup) throws Exception {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                throw new Exception("Job does not exist");
            }

            scheduler.pauseJob(jobKey);
            log.info("Job paused: {} in group {}", jobName, jobGroup);

            TriggerKey triggerKey = new TriggerKey(jobName, jobGroup);
            Trigger trigger = scheduler.getTrigger(triggerKey);

            return buildJobResponse(jobKey, Trigger.TriggerState.PAUSED.name(),
                    "Job paused successfully", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error pausing job: ", e);
            throw new Exception("Failed to pause job: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse resumeJob(String jobName, String jobGroup) throws Exception {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                throw new Exception("Job does not exist");
            }

            scheduler.resumeJob(jobKey);
            log.info("Job resumed: {} in group {}", jobName, jobGroup);

            TriggerKey triggerKey = new TriggerKey(jobName, jobGroup);
            Trigger trigger = scheduler.getTrigger(triggerKey);

            return buildJobResponse(jobKey, Trigger.TriggerState.NORMAL.name(),
                    "Job resumed successfully", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error resuming job: ", e);
            throw new Exception("Failed to resume job: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse updateJobSchedule(String jobName, String jobGroup, String cronExpression) throws Exception {
        try {
            TriggerKey triggerKey = new TriggerKey(jobName, jobGroup);
            Trigger oldTrigger = scheduler.getTrigger(triggerKey);

            if (oldTrigger == null) {
                throw new Exception("Trigger does not exist");
            }

            JobKey jobKey = oldTrigger.getJobKey();

            // 构建新的Cron触发器
            CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(cronExpression);
            CronTrigger newTrigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(scheduleBuilder)
                    .build();

            // 更新触发器
            scheduler.rescheduleJob(triggerKey, newTrigger);
            log.info("Job schedule updated: {} in group {} with cron: {}",
                    jobName, jobGroup, cronExpression);

            return buildJobResponse(jobKey, Trigger.TriggerState.NORMAL.name(),
                    "Job schedule updated successfully", newTrigger.getNextFireTime(), newTrigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error updating job schedule: ", e);
            throw new Exception("Failed to update job schedule: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse deleteJob(String jobName, String jobGroup) throws Exception {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                throw new Exception("Job does not exist");
            }

            scheduler.deleteJob(jobKey);
            log.info("Job deleted: {} in group {}", jobName, jobGroup);

            return JobResponse.builder()
                    .jobName(jobName)
                    .jobGroup(jobGroup)
                    .status("DELETED")
                    .message("Job deleted successfully")
                    .build();
        } catch (Exception e) {
            log.error("Error deleting job: ", e);
            throw new Exception("Failed to delete job: " + e.getMessage(), e);
        }
    }

    @Override
    public List<JobResponse> getAllJobs() throws Exception {
        try {
            List<JobResponse> jobResponses = new ArrayList<>();

            // 获取所有作业组
            for (String group : scheduler.getJobGroupNames()) {
                // 获取组内所有作业
                for (JobKey jobKey : scheduler.getJobKeys(GroupMatcher.jobGroupEquals(group))) {
                    String jobName = jobKey.getName();
                    String jobGroup = jobKey.getGroup();

                    // 获取作业对应的触发器
                    List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);

                    for (Trigger trigger : triggers) {
                        Trigger.TriggerState triggerState = scheduler.getTriggerState(trigger.getKey());

                        JobResponse jobResponse = buildJobResponse(jobKey, triggerState.name(),
                                "Job fetched successfully", trigger.getNextFireTime(), trigger.getPreviousFireTime());

                        jobResponses.add(jobResponse);
                    }
                }
            }

            return jobResponses;
        } catch (Exception e) {
            log.error("Error getting all jobs: ", e);
            throw new Exception("Failed to get all jobs: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse getJobDetail(String jobName, String jobGroup) throws Exception {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                throw new Exception("Job does not exist");
            }

            List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
            if (triggers == null || triggers.isEmpty()) {
                throw new Exception("No triggers found for job");
            }

            Trigger trigger = triggers.get(0);
            Trigger.TriggerState triggerState = scheduler.getTriggerState(trigger.getKey());

            return buildJobResponse(jobKey, triggerState.name(),
                    "Job details fetched successfully", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error getting job detail: ", e);
            throw new Exception("Failed to get job detail: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse triggerJobNow(String jobName, String jobGroup) throws Exception {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                throw new Exception("Job does not exist");
            }

            scheduler.triggerJob(jobKey);
            log.info("Job triggered: {} in group {}", jobName, jobGroup);

            TriggerKey triggerKey = new TriggerKey(jobName, jobGroup);
            Trigger trigger = scheduler.getTrigger(triggerKey);

            return buildJobResponse(jobKey, "TRIGGERED",
                    "Job triggered successfully", trigger != null ? trigger.getNextFireTime() : null,
                    trigger != null ? trigger.getPreviousFireTime() : null);
        } catch (Exception e) {
            log.error("Error triggering job: ", e);
            throw new Exception("Failed to trigger job: " + e.getMessage(), e);
        }
    }

    @Override
    public JobResponse updateJobData(String jobName, String jobGroup, Map<String, Object> jobData) throws Exception {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                throw new Exception("Job does not exist");
            }

            // 获取当前JobDetail
            JobDetail jobDetail = scheduler.getJobDetail(jobKey);

            // 创建新的JobDataMap并合并新旧数据
            JobDataMap newJobDataMap = new JobDataMap();
            newJobDataMap.putAll(jobDetail.getJobDataMap());
            newJobDataMap.putAll(jobData);

            // 创建更新后的JobDetail
            JobDetail newJobDetail = jobDetail.getJobBuilder()
                    .usingJobData(newJobDataMap)
                    .build();

            // 更新JobDetail
            scheduler.addJob(newJobDetail, true);
            log.info("Job data updated: {} in group {}", jobName, jobGroup);

            // 获取触发器状态
            List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
            if (triggers == null || triggers.isEmpty()) {
                return buildJobResponse(jobKey, "UNKNOWN",
                        "Job data updated successfully but no triggers found", null, null);
            }

            Trigger trigger = triggers.get(0);
            Trigger.TriggerState triggerState = scheduler.getTriggerState(trigger.getKey());

            return buildJobResponse(jobKey, triggerState.name(),
                    "Job data updated successfully", trigger.getNextFireTime(), trigger.getPreviousFireTime());
        } catch (Exception e) {
            log.error("Error updating job data: ", e);
            throw new Exception("Failed to update job data: " + e.getMessage(), e);
        }
    }

    // 构建JobDetail的辅助方法
    private JobDetail buildJobDetail(String jobName, String jobGroup, Class<? extends Job> jobClass,
                                     String description, Map<String, Object> jobData, boolean durability) {
        JobDataMap dataMap = new JobDataMap();
        if (jobData != null) {
            dataMap.putAll(jobData);
        }

        return JobBuilder.newJob(jobClass)
                .withIdentity(jobName, jobGroup)
                .withDescription(description)
                .usingJobData(dataMap)
                .storeDurably(durability)
                .build();
    }

    // 构建Cron触发器的辅助方法
    private Trigger buildCronTrigger(String triggerName, String triggerGroup, String cronExpression) {
        return TriggerBuilder.newTrigger()
                .withIdentity(triggerName, triggerGroup)
                .withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)
                        .withMisfireHandlingInstructionFireAndProceed())
                .build();
    }

    // 构建简单触发器的辅助方法
    // 构建简单触发器的辅助方法
    private Trigger buildSimpleTrigger(String triggerName, String triggerGroup,
                                       int repeatCount, long repeatInterval, long startDelay) {
        SimpleScheduleBuilder scheduleBuilder = SimpleScheduleBuilder.simpleSchedule()
                .withIntervalInMilliseconds(repeatInterval);

        if (repeatCount > 0) {
            scheduleBuilder.withRepeatCount(repeatCount);
        } else if (repeatCount < 0) {
            scheduleBuilder.repeatForever();
        }

        // 修改这里，使用通配符泛型或不指定具体泛型类型
        TriggerBuilder<?> triggerBuilder = TriggerBuilder.newTrigger()
                .withIdentity(triggerName, triggerGroup)
                .withSchedule(scheduleBuilder);

        if (startDelay > 0) {
            triggerBuilder.startAt(new Date(System.currentTimeMillis() + startDelay));
        } else {
            triggerBuilder.startNow();
        }

        return triggerBuilder.build();
    }

    // 构建作业响应的辅助方法
    private JobResponse buildJobResponse(JobKey jobKey, String status, String message,
                                         Date nextFireTime, Date previousFireTime) {
        return JobResponse.builder()
                .jobName(jobKey.getName())
                .jobGroup(jobKey.getGroup())
                .status(status)
                .message(message)
                .nextFireTime(nextFireTime)
                .previousFireTime(previousFireTime)
                .build();
    }
}