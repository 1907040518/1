package com.scheduler.job;

import lombok.extern.slf4j.Slf4j;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@Slf4j
@PersistJobDataAfterExecution
public class EmailJob extends BaseJob {

    @Override
    protected void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception {
        String recipient = dataMap.getString("recipient");
        String subject = dataMap.getString("subject");
        String body = dataMap.getString("body");

        log.info("Preparing to send email to: {}", recipient);

        // 这里我们模拟发送邮件，实际应用中可使用JavaMailSender发送真实邮件
        log.info("Sending email to: {} with subject: {}", recipient, subject);
        log.info("Email body: {}", body);

        // 模拟网络延迟
        Thread.sleep(2000);

        log.info("Email sent successfully to: {}", recipient);
    }

    // 如果需要实际发送邮件，可以取消注释此代码并配置邮件发送器
    /*
    private void sendActualEmail(String recipient, String subject, String body) {
        JavaMailSender mailSender = getBean(context, JavaMailSender.class);

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(recipient);
        message.setSubject(subject);
        message.setText(body);

        mailSender.send(message);
    }
    */
}