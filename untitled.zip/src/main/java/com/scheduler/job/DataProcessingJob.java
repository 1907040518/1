package com.scheduler.job;

import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;

import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

@Slf4j
@DisallowConcurrentExecution // 防止并发执行
@PersistJobDataAfterExecution
public class DataProcessingJob extends BaseJob {

    @Override
    protected void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception {
        String dataSource = dataMap.getString("dataSource");
        int batchSize = dataMap.getIntValue("batchSize");

        log.info("Starting data processing job at {}", LocalDateTime.now());
        log.info("Processing data from: {} with batch size: {}", dataSource, batchSize);

        // 记录处理开始时间
        long startTime = System.currentTimeMillis();

        // 模拟数据处理
        processData(dataSource, batchSize);

        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        // 更新作业数据，记录执行统计信息
        int totalRuns = dataMap.containsKey("totalRuns") ? dataMap.getInt("totalRuns") + 1 : 1;
        long totalExecutionTime = dataMap.containsKey("totalExecutionTime") ?
                dataMap.getLong("totalExecutionTime") + executionTime : executionTime;

        dataMap.put("totalRuns", totalRuns);
        dataMap.put("totalExecutionTime", totalExecutionTime);
        dataMap.put("avgExecutionTime", totalExecutionTime / totalRuns);
        dataMap.put("lastExecutionTime", executionTime);
        dataMap.put("lastRunAt", System.currentTimeMillis());

        log.info("Data processing job completed in {} ms", executionTime);
    }

    private void processData(String dataSource, int batchSize) throws InterruptedException {
        // 模拟数据处理过程
        log.info("Connecting to data source: {}", dataSource);
        Thread.sleep(1000); // 模拟连接时间

        log.info("Fetching {} records", batchSize);
        Thread.sleep(500); // 模拟数据获取

        // 模拟处理每一批数据，时间随机
        int batches = ThreadLocalRandom.current().nextInt(3, 8);
        for (int i = 0; i < batches; i++) {
            int recordsInBatch = ThreadLocalRandom.current().nextInt(100, batchSize + 1);
            log.info("Processing batch {} with {} records", i + 1, recordsInBatch);

            int successCount = recordsInBatch - ThreadLocalRandom.current().nextInt(0, 10); // 模拟部分失败

            // 模拟处理时间，随机 1-5 秒
            Thread.sleep(ThreadLocalRandom.current().nextInt(1000, 5000));

            log.info("Batch {} completed: {} records processed successfully", i + 1, successCount);
        }

        log.info("Data processing completed for source: {}", dataSource);
    }
}