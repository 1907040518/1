package com.scheduler.job;

import lombok.extern.slf4j.Slf4j;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.PersistJobDataAfterExecution;

@Slf4j
@PersistJobDataAfterExecution
public class SimpleJob extends BaseJob {

    @Override
    protected void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception {
        String message = dataMap.getString("message");
        log.info("SimpleJob executing with message: {}", message);

        // 获取计数器
        int count = dataMap.getInt("count");
        log.info("Current execution count: {}", count);

        // 更新计数器
        dataMap.put("count", count + 1);

        // 模拟工作耗时
        Thread.sleep(1000);

        log.info("SimpleJob completed");
    }
}