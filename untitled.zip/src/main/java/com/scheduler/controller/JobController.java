package com.scheduler.controller;

import com.scheduler.job.DataProcessingJob;
import com.scheduler.job.EmailJob;
import com.scheduler.job.SimpleJob;
import com.scheduler.model.JobInfo;
import com.scheduler.model.JobResponse;
import com.scheduler.service.JobService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/jobs")
public class JobController {

    @Autowired
    private JobService jobService;

    @PostMapping
    public ResponseEntity<JobResponse> createJob(@RequestBody JobInfo jobInfo) {
        try {
            JobResponse response = jobService.scheduleJob(jobInfo);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error creating job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(jobInfo.getJobName())
                            .jobGroup(jobInfo.getJobGroup())
                            .status("ERROR")
                            .message("Failed to create job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PostMapping("/cron")
    public ResponseEntity<JobResponse> createCronJob(@RequestBody JobInfo jobInfo) {
        try {
            String jobClassName = jobInfo.getJobClass();
            Class<?> jobClass = Class.forName(jobClassName);

            JobResponse response = jobService.scheduleJobWithCron(
                    jobInfo.getJobName(),
                    jobInfo.getJobGroup(),
                    jobClass,
                    jobInfo.getCronExpression(),
                    jobInfo.getJobData()
            );

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error creating cron job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(jobInfo.getJobName())
                            .jobGroup(jobInfo.getJobGroup())
                            .status("ERROR")
                            .message("Failed to create cron job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PostMapping("/simple")
    public ResponseEntity<JobResponse> createSimpleJob(@RequestBody JobInfo jobInfo) {
        try {
            String jobClassName = jobInfo.getJobClass();
            Class<?> jobClass = Class.forName(jobClassName);

            JobResponse response = jobService.scheduleJobWithSimpleTrigger(
                    jobInfo.getJobName(),
                    jobInfo.getJobGroup(),
                    jobClass,
                    jobInfo.getRepeatCount(),
                    jobInfo.getRepeatInterval(),
                    jobInfo.getJobData()
            );

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error creating simple job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(jobInfo.getJobName())
                            .jobGroup(jobInfo.getJobGroup())
                            .status("ERROR")
                            .message("Failed to create simple job: " + e.getMessage())
                            .build()
            );
        }
    }

    @GetMapping
    public ResponseEntity<List<JobResponse>> getAllJobs() {
        try {
            List<JobResponse> jobs = jobService.getAllJobs();
            return ResponseEntity.ok(jobs);
        } catch (Exception e) {
            log.error("Error getting all jobs: ", e);
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{group}/{name}")
    public ResponseEntity<JobResponse> getJob(@PathVariable("group") String group,
                                              @PathVariable("name") String name) {
        try {
            JobResponse job = jobService.getJobDetail(name, group);
            return ResponseEntity.ok(job);
        } catch (Exception e) {
            log.error("Error getting job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to get job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PutMapping("/{group}/{name}/pause")
    public ResponseEntity<JobResponse> pauseJob(@PathVariable("group") String group,
                                                @PathVariable("name") String name) {
        try {
            JobResponse response = jobService.pauseJob(name, group);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error pausing job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to pause job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PutMapping("/{group}/{name}/resume")
    public ResponseEntity<JobResponse> resumeJob(@PathVariable("group") String group,
                                                 @PathVariable("name") String name) {
        try {
            JobResponse response = jobService.resumeJob(name, group);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error resuming job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to resume job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PutMapping("/{group}/{name}/trigger")
    public ResponseEntity<JobResponse> triggerJob(@PathVariable("group") String group,
                                                  @PathVariable("name") String name) {
        try {
            JobResponse response = jobService.triggerJobNow(name, group);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error triggering job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to trigger job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PutMapping("/{group}/{name}/cron")
    public ResponseEntity<JobResponse> updateJobCron(@PathVariable("group") String group,
                                                     @PathVariable("name") String name,
                                                     @RequestBody Map<String, String> payload) {
        try {
            String cronExpression = payload.get("cronExpression");
            if (cronExpression == null || cronExpression.trim().isEmpty()) {
                throw new IllegalArgumentException("Cron expression cannot be empty");
            }

            JobResponse response = jobService.updateJobSchedule(name, group, cronExpression);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error updating job cron: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to update job cron: " + e.getMessage())
                            .build()
            );
        }
    }

    @PutMapping("/{group}/{name}/data")
    public ResponseEntity<JobResponse> updateJobData(@PathVariable("group") String group,
                                                     @PathVariable("name") String name,
                                                     @RequestBody Map<String, Object> jobData) {
        try {
            JobResponse response = jobService.updateJobData(name, group, jobData);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error updating job data: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to update job data: " + e.getMessage())
                            .build()
            );
        }
    }

    @DeleteMapping("/{group}/{name}")
    public ResponseEntity<JobResponse> deleteJob(@PathVariable("group") String group,
                                                 @PathVariable("name") String name) {
        try {
            JobResponse response = jobService.deleteJob(name, group);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error deleting job: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName(name)
                            .jobGroup(group)
                            .status("ERROR")
                            .message("Failed to delete job: " + e.getMessage())
                            .build()
            );
        }
    }

    @PostMapping("/examples/simple")
    public ResponseEntity<JobResponse> createSimpleJobExample() {
        try {
            Map<String, Object> jobData = new HashMap<>();
            jobData.put("message", "This is a simple job example");
            jobData.put("count", 0);

            JobResponse response = jobService.scheduleJobWithSimpleTrigger(
                    "simpleJob",
                    "examples",
                    SimpleJob.class,
                    5, // repeat 5 times
                    30000, // every 30 seconds
                    jobData
            );

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error creating simple job example: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName("simpleJob")
                            .jobGroup("examples")
                            .status("ERROR")
                            .message("Failed to create simple job example: " + e.getMessage())
                            .build()
            );
        }
    }

    @PostMapping("/examples/email")
    public ResponseEntity<JobResponse> createEmailJobExample() {
        try {
            Map<String, Object> jobData = new HashMap<>();
            jobData.put("recipient", "user@example.com");
            jobData.put("subject", "Scheduled Email");
            jobData.put("body", "This is a scheduled email sent by Quartz job scheduler.");

            JobResponse response = jobService.scheduleJobWithCron(
                    "emailJob",
                    "examples",
                    EmailJob.class,
                    "0 0/5 * * * ?", // every 5 minutes
                    jobData
            );

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error creating email job example: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName("emailJob")
                            .jobGroup("examples")
                            .status("ERROR")
                            .message("Failed to create email job example: " + e.getMessage())
                            .build()
            );
        }
    }

    @PostMapping("/examples/data-processing")
    public ResponseEntity<JobResponse> createDataProcessingJobExample() {
        try {
            Map<String, Object> jobData = new HashMap<>();
            jobData.put("dataSource", "mysql://localhost:3306/sample_db");
            jobData.put("batchSize", 1000);

            JobResponse response = jobService.scheduleJobWithCron(
                    "dataProcessingJob",
                    "examples",
                    DataProcessingJob.class,
                    "0 0 */1 * * ?", // every hour
                    jobData
            );

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error creating data processing job example: ", e);
            return ResponseEntity.badRequest().body(
                    JobResponse.builder()
                            .jobName("dataProcessingJob")
                            .jobGroup("examples")
                            .status("ERROR")
                            .message("Failed to create data processing job example: " + e.getMessage())
                            .build()
            );
        }
    }
}