package com.scheduler.model;

import lombok.Data;

import java.util.Map;

@Data
public class JobInfo {
    private String jobName;
    private String jobGroup;
    private String jobClass;
    private String cronExpression;
    private String description;
    private Map<String, Object> jobData;
    private boolean durability = true;
    private long repeatInterval; // 用于简单触发器
    private int repeatCount; // 用于简单触发器
    private String scheduleType; // CRON 或 SIMPLE
    private long startDelay; // 开始延迟（毫秒）
}