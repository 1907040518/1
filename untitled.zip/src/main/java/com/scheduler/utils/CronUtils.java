package com.scheduler.utils;

import org.quartz.CronExpression;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class CronUtils {

    /**
     * 验证Cron表达式是否有效
     */
    public static boolean isValidCronExpression(String cronExpression) {
        try {
            CronExpression.validateExpression(cronExpression);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * 计算未来N次的触发时间
     */
    public static List<Date> getNextFireTimes(String cronExpression, int numTimes) throws ParseException {
        if (!isValidCronExpression(cronExpression)) {
            throw new ParseException("Invalid cron expression: " + cronExpression, 0);
        }

        CronExpression cron = new CronExpression(cronExpression);
        List<Date> dates = new ArrayList<>();

        Date nextDate = new Date();
        for (int i = 0; i < numTimes; i++) {
            nextDate = cron.getNextValidTimeAfter(nextDate);
            if (nextDate != null) {
                dates.add(nextDate);
            } else {
                break;
            }
        }

        return dates;
    }

    /**
     * 获取通用的Cron表达式示例
     */
    public static String getCommonCronExpressions(String type) {
        switch (type.toLowerCase()) {
            case "every_minute":
                return "0 * * * * ?";
            case "every_5_minutes":
                return "0 */5 * * * ?";
            case "every_hour":
                return "0 0 * * * ?";
            case "every_day_midnight":
                return "0 0 0 * * ?";
            case "every_day_noon":
                return "0 0 12 * * ?";
            case "every_monday":
                return "0 0 0 ? * MON";
            case "every_weekday":
                return "0 0 0 ? * MON-FRI";
            case "every_month_first_day":
                return "0 0 0 1 * ?";
            default:
                return null;
        }
    }

    /**
     * 生成描述性的Cron表达式说明
     */
    public static String describeCronExpression(String cronExpression) {
        try {
            if (!isValidCronExpression(cronExpression)) {
                return "Invalid cron expression";
            }

            // 简化的描述生成逻辑，实际应用中可以更复杂
            if (cronExpression.equals("0 * * * * ?")) {
                return "Triggers every minute";
            } else if (cronExpression.equals("0 */5 * * * ?")) {
                return "Triggers every 5 minutes";
            } else if (cronExpression.equals("0 0 * * * ?")) {
                return "Triggers every hour at the top of the hour";
            } else if (cronExpression.equals("0 0 0 * * ?")) {
                return "Triggers every day at midnight";
            } else if (cronExpression.equals("0 0 12 * * ?")) {
                return "Triggers every day at noon";
            } else if (cronExpression.equals("0 0 0 ? * MON")) {
                return "Triggers every Monday at midnight";
            } else {
                List<Date> nextDates = getNextFireTimes(cronExpression, 3);
                StringBuilder sb = new StringBuilder("Next 3 executions: ");
                for (int i = 0; i < nextDates.size(); i++) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(nextDates.get(i));
                }
                return sb.toString();
            }
        } catch (Exception e) {
            return "Error describing cron expression: " + e.getMessage();
        }
    }
}