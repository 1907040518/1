package com.scheduler.service;

import com.scheduler.model.JobInfo;
import org.quartz.SchedulerException;

import java.util.List;

public interface JobService {

    /**
     * 添加并调度一个新任务
     * @param jobInfo 任务信息
     * @return 添加结果
     * @throws SchedulerException 调度异常
     */
    boolean addJob(JobInfo jobInfo) throws SchedulerException;

    /**
     * 更新现有任务
     * @param jobInfo 任务信息
     * @return 更新结果
     * @throws SchedulerException 调度异常
     */
    boolean updateJob(JobInfo jobInfo) throws SchedulerException;

    /**
     * 删除任务
     * @param jobName 任务名称
     * @param jobGroup 任务组名
     * @return 删除结果
     * @throws SchedulerException 调度异常
     */
    boolean deleteJob(String jobName, String jobGroup) throws SchedulerException;

    /**
     * 暂停任务
     * @param jobName 任务名称
     * @param jobGroup 任务组名
     * @return 暂停结果
     * @throws SchedulerException 调度异常
     */
    boolean pauseJob(String jobName, String jobGroup) throws SchedulerException;

    /**
     * 恢复已暂停的任务
     * @param jobName 任务名称
     * @param jobGroup 任务组名
     * @return 恢复结果
     * @throws SchedulerException 调度异常
     */
    boolean resumeJob(String jobName, String jobGroup) throws SchedulerException;

    /**
     * 立即触发一次任务执行
     * @param jobName 任务名称
     * @param jobGroup 任务组名
     * @return 触发结果
     * @throws SchedulerException 调度异常
     */
    boolean triggerJob(String jobName, String jobGroup) throws SchedulerException;

    /**
     * 获取所有任务
     * @return 任务列表
     * @throws SchedulerException 调度异常
     */
    List<JobInfo> getAllJobs() throws SchedulerException;

    /**
     * 根据任务名和组名获取任务
     * @param jobName 任务名称
     * @param jobGroup 任务组名
     * @return 任务信息
     * @throws SchedulerException 调度异常
     */
    JobInfo getJob(String jobName, String jobGroup) throws SchedulerException;

    /**
     * 检查任务是否存在
     * @param jobName 任务名称
     * @param jobGroup 任务组名
     * @return 是否存在
     * @throws SchedulerException 调度异常
     */
    boolean checkExists(String jobName, String jobGroup) throws SchedulerException;
}