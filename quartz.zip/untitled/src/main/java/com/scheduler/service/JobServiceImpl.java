package com.scheduler.service;

import com.scheduler.model.JobInfo;
import org.quartz.*;
import org.quartz.impl.matchers.GroupMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Service
public class JobServiceImpl implements JobService {

    private static final Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

    @Autowired
    private Scheduler scheduler;

    @Override
    public boolean addJob(JobInfo jobInfo) throws SchedulerException {
        logger.info("Adding job: {}", jobInfo.getJobName());

        try {
            // 检查任务是否已存在
            if (checkExists(jobInfo.getJobName(), jobInfo.getJobGroup())) {
                logger.warn("Job already exists: {}.{}", jobInfo.getJobGroup(), jobInfo.getJobName());
                return false;
            }

            // 构建JobDetail
            Class<? extends Job> jobClass = (Class<? extends Job>) Class.forName(jobInfo.getJobClass());
            JobDetail jobDetail = JobBuilder.newJob(jobClass)
                    .withIdentity(jobInfo.getJobName(), jobInfo.getJobGroup())
                    .withDescription(jobInfo.getJobDescription())
                    .storeDurably(jobInfo.isDurability())
                    .build();

            // 添加JobDataMap
            if (jobInfo.getJobData() != null) {
                jobDetail.getJobDataMap().putAll(jobInfo.getJobData());
            }

            // 创建触发器
            Trigger trigger;
            if ("SIMPLE".equalsIgnoreCase(jobInfo.getScheduleType())) {
                // 简单触发器
                SimpleScheduleBuilder scheduleBuilder = SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInMilliseconds(jobInfo.getRepeatInterval());

                if (jobInfo.getRepeatCount() > 0) {
                    scheduleBuilder.withRepeatCount(jobInfo.getRepeatCount());
                } else {
                    scheduleBuilder.repeatForever();
                }

                trigger = TriggerBuilder.newTrigger()
                        .withIdentity(jobInfo.getJobName() + "Trigger", jobInfo.getJobGroup())
                        .withDescription(jobInfo.getJobDescription())
                        .startAt(new Date(System.currentTimeMillis() + jobInfo.getStartDelay()))
                        .withSchedule(scheduleBuilder)
                        .build();
            } else {
                // Cron触发器
                trigger = TriggerBuilder.newTrigger()
                        .withIdentity(jobInfo.getJobName() + "Trigger", jobInfo.getJobGroup())
                        .withDescription(jobInfo.getJobDescription())
                        .startAt(new Date(System.currentTimeMillis() + jobInfo.getStartDelay()))
                        .withSchedule(CronScheduleBuilder.cronSchedule(jobInfo.getCronExpression()))
                        .build();
            }

            // 调度任务
            scheduler.scheduleJob(jobDetail, trigger);

            if (scheduler.isShutdown()) {
                logger.info("Starting scheduler...");
                scheduler.start();
            }

            logger.info("Job scheduled successfully: {}.{}", jobInfo.getJobGroup(), jobInfo.getJobName());
            return true;

        } catch (ClassNotFoundException e) {
            logger.error("Job class not found: {}", jobInfo.getJobClass(), e);
            throw new SchedulerException("Job class not found: " + jobInfo.getJobClass(), e);
        }
    }

    @Override
    public boolean updateJob(JobInfo jobInfo) throws SchedulerException {
        logger.info("Updating job: {}", jobInfo.getJobName());

        try {
            // 检查任务是否存在
            if (!checkExists(jobInfo.getJobName(), jobInfo.getJobGroup())) {
                logger.warn("Job does not exist: {}.{}", jobInfo.getJobGroup(), jobInfo.getJobName());
                return false;
            }

            TriggerKey triggerKey = TriggerKey.triggerKey(jobInfo.getJobName() + "Trigger", jobInfo.getJobGroup());

            // 创建新的触发器
            Trigger newTrigger;
            if ("SIMPLE".equalsIgnoreCase(jobInfo.getScheduleType())) {
                // 简单触发器
                SimpleScheduleBuilder scheduleBuilder = SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInMilliseconds(jobInfo.getRepeatInterval());

                if (jobInfo.getRepeatCount() > 0) {
                    scheduleBuilder.withRepeatCount(jobInfo.getRepeatCount());
                } else {
                    scheduleBuilder.repeatForever();
                }

                newTrigger = TriggerBuilder.newTrigger()
                        .withIdentity(triggerKey)
                        .withDescription(jobInfo.getJobDescription())
                        .withSchedule(scheduleBuilder)
                        .startAt(new Date(System.currentTimeMillis() + jobInfo.getStartDelay()))
                        .build();
            } else {
                // Cron触发器
                newTrigger = TriggerBuilder.newTrigger()
                        .withIdentity(triggerKey)
                        .withDescription(jobInfo.getJobDescription())
                        .withSchedule(CronScheduleBuilder.cronSchedule(jobInfo.getCronExpression()))
                        .startAt(new Date(System.currentTimeMillis() + jobInfo.getStartDelay()))
                        .build();
            }

            // 更新任务数据
            JobKey jobKey = JobKey.jobKey(jobInfo.getJobName(), jobInfo.getJobGroup());
            JobDetail jobDetail = scheduler.getJobDetail(jobKey);

            if (jobInfo.getJobData() != null) {
                jobDetail.getJobDataMap().clear();
                jobDetail.getJobDataMap().putAll(jobInfo.getJobData());
            }

            // 重新调度任务
            scheduler.rescheduleJob(triggerKey, newTrigger);
            logger.info("Job updated successfully: {}.{}", jobInfo.getJobGroup(), jobInfo.getJobName());
            return true;

        } catch (Exception e) {
            logger.error("Failed to update job: {}", jobInfo.getJobName(), e);
            throw new SchedulerException("Failed to update job: " + jobInfo.getJobName(), e);
        }
    }

    @Override
    public boolean deleteJob(String jobName, String jobGroup) throws SchedulerException {
        logger.info("Deleting job: {}.{}", jobGroup, jobName);

        JobKey jobKey = JobKey.jobKey(jobName, jobGroup);

        if (!scheduler.checkExists(jobKey)) {
            logger.warn("Job does not exist: {}.{}", jobGroup, jobName);
            return false;
        }

        return scheduler.deleteJob(jobKey);
    }

    @Override
    public boolean pauseJob(String jobName, String jobGroup) throws SchedulerException {
        logger.info("Pausing job: {}.{}", jobGroup, jobName);

        JobKey jobKey = JobKey.jobKey(jobName, jobGroup);

        if (!scheduler.checkExists(jobKey)) {
            logger.warn("Job does not exist: {}.{}", jobGroup, jobName);
            return false;
        }

        scheduler.pauseJob(jobKey);
        return true;
    }

    @Override
    public boolean resumeJob(String jobName, String jobGroup) throws SchedulerException {
        logger.info("Resuming job: {}.{}", jobGroup, jobName);

        JobKey jobKey = JobKey.jobKey(jobName, jobGroup);

        if (!scheduler.checkExists(jobKey)) {
            logger.warn("Job does not exist: {}.{}", jobGroup, jobName);
            return false;
        }

        scheduler.resumeJob(jobKey);
        return true;
    }

    @Override
    public boolean triggerJob(String jobName, String jobGroup) throws SchedulerException {
        logger.info("Triggering job: {}.{}", jobGroup, jobName);

        JobKey jobKey = JobKey.jobKey(jobName, jobGroup);

        if (!scheduler.checkExists(jobKey)) {
            logger.warn("Job does not exist: {}.{}", jobGroup, jobName);
            return false;
        }

        scheduler.triggerJob(jobKey);
        return true;
    }

    @Override
    public List<JobInfo> getAllJobs() throws SchedulerException {
        List<JobInfo> jobList = new ArrayList<>();

        // 获取所有任务组
        List<String> jobGroupNames = scheduler.getJobGroupNames();

        for (String groupName : jobGroupNames) {
            // 获取组内所有任务
            Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName));

            for (JobKey jobKey : jobKeys) {
                JobInfo jobInfo = getJobInfoFromKey(jobKey);
                if (jobInfo != null) {
                    jobList.add(jobInfo);
                }
            }
        }

        return jobList;
    }

    @Override
    public JobInfo getJob(String jobName, String jobGroup) throws SchedulerException {
        JobKey jobKey = JobKey.jobKey(jobName, jobGroup);

        if (!scheduler.checkExists(jobKey)) {
            logger.warn("Job does not exist: {}.{}", jobGroup, jobName);
            return null;
        }

        return getJobInfoFromKey(jobKey);
    }

    @Override
    public boolean checkExists(String jobName, String jobGroup) throws SchedulerException {
        return scheduler.checkExists(JobKey.jobKey(jobName, jobGroup));
    }

    // 辅助方法：从JobKey获取JobInfo
    private JobInfo getJobInfoFromKey(JobKey jobKey) throws SchedulerException {
        try {
            JobDetail jobDetail = scheduler.getJobDetail(jobKey);
            List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);

            if (jobDetail == null || triggers.isEmpty()) {
                return null;
            }

            Trigger trigger = triggers.get(0);
            JobInfo jobInfo = new JobInfo();

            // 设置基本信息
            jobInfo.setJobName(jobKey.getName());
            jobInfo.setJobGroup(jobKey.getGroup());
            jobInfo.setJobClass(jobDetail.getJobClass().getName());
            jobInfo.setJobDescription(jobDetail.getDescription());
            jobInfo.setDurability(jobDetail.isDurable());

            // 设置任务数据
            jobInfo.setJobData(new java.util.HashMap<>(jobDetail.getJobDataMap()));

            // 设置触发器信息
            if (trigger instanceof CronTrigger) {
                CronTrigger cronTrigger = (CronTrigger) trigger;
                jobInfo.setCronExpression(cronTrigger.getCronExpression());
                jobInfo.setScheduleType("CRON");
            } else if (trigger instanceof SimpleTrigger) {
                SimpleTrigger simpleTrigger = (SimpleTrigger) trigger;
                jobInfo.setRepeatInterval(simpleTrigger.getRepeatInterval());
                jobInfo.setRepeatCount(simpleTrigger.getRepeatCount());
                jobInfo.setScheduleType("SIMPLE");
            }

            // 设置任务状态
            Trigger.TriggerState triggerState = scheduler.getTriggerState(trigger.getKey());
            switch (triggerState) {
                case NORMAL:
                    jobInfo.setJobStatus("NORMAL");
                    break;
                case PAUSED:
                    jobInfo.setJobStatus("PAUSED");
                    break;
                case COMPLETE:
                    jobInfo.setJobStatus("COMPLETE");
                    break;
                case ERROR:
                    jobInfo.setJobStatus("ERROR");
                    break;
                case BLOCKED:
                    jobInfo.setJobStatus("BLOCKED");
                    break;
                case NONE:
                    jobInfo.setJobStatus("NONE");
                    break;
                default:
                    jobInfo.setJobStatus("UNKNOWN");
            }

            return jobInfo;

        } catch (Exception e) {
            logger.error("Error getting job info for: {}", jobKey, e);
            return null;
        }
    }
}