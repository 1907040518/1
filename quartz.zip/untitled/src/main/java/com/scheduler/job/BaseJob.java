package com.scheduler.job;

import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.springframework.context.ApplicationContext;

@Slf4j
public abstract class BaseJob implements Job {

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            JobKey jobKey = context.getJobDetail().getKey();
            log.info("Job {} in group {} is executing at: {}",
                    jobKey.getName(), jobKey.getGroup(), new java.util.Date());

            // 获取Job数据
            JobDataMap dataMap = context.getMergedJobDataMap();

            // 执行具体任务逻辑
            executeJob(context, dataMap);

            log.info("Job {} in group {} completed successfully",
                    jobKey.getName(), jobKey.getGroup());
        } catch (Exception e) {
            log.error("Error executing job: ", e);
            JobExecutionException jobException = new JobExecutionException(e);
            // 设置重新执行策略
            jobException.setRefireImmediately(false);
            throw jobException;
        }
    }

    // 抽象方法，具体的作业逻辑由子类实现
    protected abstract void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception;

    // 从Spring上下文获取Bean的通用方法
    protected <T> T getBean(JobExecutionContext context, Class<T> beanClass) {
        try {
            ApplicationContext appContext = (ApplicationContext) context.getScheduler()
                    .getContext().get("applicationContext");
            return appContext.getBean(beanClass);
        } catch (SchedulerException e) {
            log.error("Error getting application context: ", e);
            throw new RuntimeException("Failed to get bean from context", e);
        }
    }
}