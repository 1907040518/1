//package com.scheduler.job;
//
//import org.quartz.JobDataMap;
//import org.quartz.JobExecutionContext;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Component;
//
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//
//@Component
//public class LoggingJob extends BaseJob {
//
//    private static final Logger logger = LoggerFactory.getLogger(LoggingJob.class);
//    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//
//    @Override
//    protected void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception {
//        String currentTime = LocalDateTime.now().format(formatter);
//        String message = "This is a scheduled logging task running at: " + currentTime;
//
//        // 获取任务参数（如果有的话）
//        String taskId = dataMap.getString("taskId");
//        if (taskId != null && !taskId.isEmpty()) {
//            message += " (Task ID: " + taskId + ")";
//        }
//
//        logger.info(message);
//        System.out.println(message);
//
//    }
//}
package com.scheduler.job;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class LoggingJob extends BaseJob {

    private static final Logger logger = LoggerFactory.getLogger(LoggingJob.class);
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception {
        String currentTime = LocalDateTime.now().format(formatter);
        logger.info("Scheduled Logging Job is running at: {}", currentTime);
        System.out.println("Scheduled Logging Job is running at: " + currentTime);
    }
}