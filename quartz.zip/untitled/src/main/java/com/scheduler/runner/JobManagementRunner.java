package com.scheduler.runner;

import com.scheduler.model.JobInfo;
import com.scheduler.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

@Component
@Order(2) // 确保在任务创建之后运行
public class JobManagementRunner implements CommandLineRunner {

    @Autowired
    private JobService jobService;

    @Override
    public void run(String... args) throws Exception {
        // 等待任务至少执行一次
        System.out.println("Waiting for job to execute at least once...");
        TimeUnit.SECONDS.sleep(65); // 等待65秒，确保任务至少执行一次

        // 显示菜单并处理用户输入
        showMenu();
    }

    private void showMenu() throws Exception {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\n===== 任务管理菜单 =====");
            System.out.println("1. 查看所有任务");
            System.out.println("2. 暂停任务");
            System.out.println("3. 恢复任务");
            System.out.println("4. 删除任务");
            System.out.println("5. 退出");
            System.out.print("请选择操作 (1-5): ");

            int choice = 5;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("无效输入，请输入1-5之间的数字");
                continue;
            }

            switch (choice) {
                case 1:
                    listAllJobs();
                    break;
                case 2:
                    pauseJob(scanner);
                    break;
                case 3:
                    resumeJob(scanner);
                    break;
                case 4:
                    deleteJob(scanner);
                    break;
                case 5:
                    exit = true;
                    System.out.println("程序将继续运行，但管理界面已退出");
                    break;
                default:
                    System.out.println("无效选择，请重试");
            }
        }
    }

    private void listAllJobs() {
        try {
            List<JobInfo> jobs = jobService.getAllJobs();
            System.out.println("\n当前所有任务:");
            if (jobs.isEmpty()) {
                System.out.println("没有找到任务");
            } else {
                for (JobInfo job : jobs) {
                    System.out.println("任务名: " + job.getJobName() +
                            ", 组: " + job.getJobGroup() +
                            ", 状态: " + job.getJobStatus() +
                            ", Cron表达式: " + job.getCronExpression());
                }
            }
        } catch (Exception e) {
            System.err.println("获取任务列表失败: " + e.getMessage());
        }
    }

    private void pauseJob(Scanner scanner) {
        System.out.print("输入要暂停的任务名: ");
        String jobName = scanner.nextLine();
        System.out.print("输入任务组名: ");
        String groupName = scanner.nextLine();

        try {
            jobService.pauseJob(jobName, groupName);
            System.out.println("任务 " + jobName + " 已暂停");
        } catch (Exception e) {
            System.err.println("暂停任务失败: " + e.getMessage());
        }
    }

    private void resumeJob(Scanner scanner) {
        System.out.print("输入要恢复的任务名: ");
        String jobName = scanner.nextLine();
        System.out.print("输入任务组名: ");
        String groupName = scanner.nextLine();

        try {
            jobService.resumeJob(jobName, groupName);
            System.out.println("任务 " + jobName + " 已恢复");
        } catch (Exception e) {
            System.err.println("恢复任务失败: " + e.getMessage());
        }
    }

    private void deleteJob(Scanner scanner) {
        System.out.print("输入要删除的任务名: ");
        String jobName = scanner.nextLine();
        System.out.print("输入任务组名: ");
        String groupName = scanner.nextLine();

        try {
            jobService.deleteJob(jobName, groupName);
            System.out.println("任务 " + jobName + " 已删除");
        } catch (Exception e) {
            System.err.println("删除任务失败: " + e.getMessage());
        }
    }
}