package com.scheduler.runner;

import com.scheduler.job.LoggingJob;
import com.scheduler.service.JobService;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

@Component
public class JobManagementRunner implements ApplicationRunner {

    private static final Logger logger = LoggerFactory.getLogger(JobManagementRunner.class);

    @Autowired
    private JobService jobService;

    @Autowired
    private Scheduler scheduler;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        logger.info("Quartz Scheduler 状态: Started={}, Standby={}, Shutdown={}",
                scheduler.isStarted(), scheduler.isInStandbyMode(), scheduler.isShutdown());

        // 启动调度器
        if (!scheduler.isStarted()) {
            scheduler.start();
            logger.info("Quartz Scheduler 已启动！");
        }

        // 添加默认的日志任务 - 每分钟执行一次
        scheduleLoggingJob();

        // 等待65秒后显示任务管理菜单
        logger.info("Waiting for job to execute at least once...");
        try {
            TimeUnit.SECONDS.sleep(65);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // 显示任务管理菜单
        showJobManagementMenu();
    }

    private void scheduleLoggingJob() {
        try {
            // 检查任务是否已存在
            JobKey jobKey = new JobKey("loggingJob", "DEFAULT");
            if (scheduler.checkExists(jobKey)) {
                logger.info("LoggingJob 已存在，跳过创建");
                return;
            }

            // 创建JobDetail
            JobDetail jobDetail = JobBuilder.newJob(LoggingJob.class)
                    .withIdentity(jobKey)
                    .withDescription("每分钟执行一次的日志任务")
                    .build();

            // 创建Trigger - 每分钟执行一次
            Trigger trigger = TriggerBuilder.newTrigger()
                    .withIdentity("loggingTrigger", "DEFAULT")
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(1)
                            .repeatForever())
                    .startNow()
                    .build();

            // 调度任务
            scheduler.scheduleJob(jobDetail, trigger);
            logger.info("成功调度 LoggingJob，将每分钟执行一次");
        } catch (Exception e) {
            logger.error("调度 LoggingJob 时出错", e);
        }
    }

    private void showJobManagementMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        // 在新线程中运行菜单，以避免阻塞主线程
        Thread menuThread = new Thread(() -> {
            while (!exit) {
                try {
                    System.out.println("\n===== 任务管理菜单 =====");
                    System.out.println("1. 查看所有任务");
                    System.out.println("2. 暂停任务");
                    System.out.println("3. 恢复任务");
                    System.out.println("4. 删除任务");
                    System.out.println("5. 退出");
                    System.out.print("请选择操作 (1-5): ");

                    int choice = scanner.nextInt();
                    scanner.nextLine(); // 消费换行符

                    switch (choice) {
                        case 1:
                            listAllJobs();
                            break;
                        case 2:
                            pauseJob(scanner);
                            break;
                        case 3:
                            resumeJob(scanner);
                            break;
                        case 4:
                            deleteJob(scanner);
                            break;
                        case 5:
                            return; // 退出线程
                        default:
                            System.out.println("无效选择，请重试");
                    }
                } catch (Exception e) {
                    logger.error("处理菜单选择时出错", e);
                    System.out.println("发生错误: " + e.getMessage());
                    scanner.nextLine(); // 清除错误输入
                }
            }
        });

        menuThread.setDaemon(true); // 设为守护线程，以便应用关闭时自动终止
        menuThread.start();
    }

    private void listAllJobs() {
        try {
            System.out.println("\n当前所有任务:");
            List<JobDetail> jobs = jobService.getAllJobs();

            if (jobs.isEmpty()) {
                System.out.println("没有找到任务");
                return;
            }

            for (JobDetail job : jobs) {
                JobKey jobKey = job.getKey();
                Trigger.TriggerState state = scheduler.getTriggerState(
                        TriggerKey.triggerKey(jobKey.getName(), jobKey.getGroup()));

                System.out.printf("Job: %s, Group: %s, Description: %s, State: %s%n",
                        jobKey.getName(), jobKey.getGroup(),
                        job.getDescription(), state);
            }
        } catch (Exception e) {
            logger.error("获取任务列表时出错", e);
            System.out.println("获取任务列表失败: " + e.getMessage());
        }
    }

    private void pauseJob(Scanner scanner) {
        try {
            System.out.print("输入要暂停的任务名称: ");
            String jobName = scanner.nextLine();

            System.out.print("输入任务组名 (默认为 DEFAULT): ");
            String groupName = scanner.nextLine();
            if (groupName.trim().isEmpty()) {
                groupName = "DEFAULT";
            }

            jobService.pauseJob(jobName, groupName);
            System.out.println("任务已暂停");
        } catch (Exception e) {
            logger.error("暂停任务时出错", e);
            System.out.println("暂停任务失败: " + e.getMessage());
        }
    }

    private void resumeJob(Scanner scanner) {
        try {
            System.out.print("输入要恢复的任务名称: ");
            String jobName = scanner.nextLine();

            System.out.print("输入任务组名 (默认为 DEFAULT): ");
            String groupName = scanner.nextLine();
            if (groupName.trim().isEmpty()) {
                groupName = "DEFAULT";
            }

            jobService.resumeJob(jobName, groupName);
            System.out.println("任务已恢复");
        } catch (Exception e) {
            logger.error("恢复任务时出错", e);
            System.out.println("恢复任务失败: " + e.getMessage());
        }
    }

    private void deleteJob(Scanner scanner) {
        try {
            System.out.print("输入要删除的任务名称: ");
            String jobName = scanner.nextLine();

            System.out.print("输入任务组名 (默认为 DEFAULT): ");
            String groupName = scanner.nextLine();
            if (groupName.trim().isEmpty()) {
                groupName = "DEFAULT";
            }

            jobService.deleteJob(jobName, groupName);
            System.out.println("任务已删除");
        } catch (Exception e) {
            logger.error("删除任务时出错", e);
            System.out.println("删除任务失败: " + e.getMessage());
        }
    }
}