package com.scheduler;

import com.scheduler.job.LoggingJob;
import com.scheduler.model.JobInfo;
import com.scheduler.service.JobService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
public class SchedulerApplication {

    // 使用构造器注入代替字段注入
    private final JobService jobService;

    // 构造器注入
    public SchedulerApplication(JobService jobService) {
        this.jobService = jobService;
    }

    public static void main(String[] args) {
        SpringApplication.run(SchedulerApplication.class, args);
    }

    /**
     * 应用启动后执行，创建并调度一个示例任务
     */
    @Bean
    public CommandLineRunner schedulingRunner() {
        return args -> {
            System.out.println("Creating and scheduling a sample logging job...");

            // 创建任务信息
            JobInfo jobInfo = new JobInfo();
            jobInfo.setJobName("sampleLoggingJob");
            jobInfo.setJobGroup("logGroup");
            jobInfo.setCronExpression("0 * * * * ?"); // 每分钟执行一次
            jobInfo.setDescription("A sample job that logs current time");
            jobInfo.setJobClass(LoggingJob.class.getName());
            jobInfo.setScheduleType("CRON"); // 使用CRON触发器

            // 添加任务参数
            Map<String, Object> jobData = new HashMap<>();
            jobData.put("taskId", "TASK-" + System.currentTimeMillis());
            jobInfo.setJobData(jobData);

            try {
                // 添加并调度任务
                jobService.addJob(jobInfo);
                System.out.println("Job scheduled successfully! It will run every minute.");
                System.out.println("Job details: " + jobInfo);
            } catch (Exception e) {
                System.err.println("Failed to schedule job: " + e.getMessage());
                e.printStackTrace();
            }
        };
    }
}