package com.scheduler.job;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class LoggingJob extends BaseJob {

    private static final Logger logger = LoggerFactory.getLogger(LoggingJob.class);
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void executeJob(JobExecutionContext context, JobDataMap dataMap) throws Exception {
        // 实现具体的任务逻辑
        String jobName = context.getJobDetail().getKey().getName();
        String jobGroup = context.getJobDetail().getKey().getGroup();
        LocalDateTime now = LocalDateTime.now();

        logger.info("=== LoggingJob 执行 ===");
        logger.info("任务名称: {}", jobName);
        logger.info("任务组: {}", jobGroup);
        logger.info("执行时间: {}", now.format(formatter));
        logger.info("下次执行时间: {}",
                context.getNextFireTime() != null
                        ? context.getNextFireTime().toString()
                        : "无");

        // 如果有数据传入，打印数据
        if (dataMap != null && !dataMap.isEmpty()) {
            logger.info("任务数据:");
            for (String key : dataMap.getKeys()) {
                logger.info("  {} = {}", key, dataMap.get(key));
            }
        }

        logger.info("=== LoggingJob 完成 ===");

        // 也打印到控制台，以便更明显地看到任务执行
        System.out.println("\n=== LoggingJob 执行于 " + now.format(formatter) + " ===");
    }
}