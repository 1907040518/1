package com.scheduler.utils;

import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Component
public class JobUtils {

    @Autowired
    private Scheduler scheduler;

    /**
     * 检查作业是否存在
     */
    public boolean jobExists(String jobName, String jobGroup) throws SchedulerException {
        return scheduler.checkExists(new JobKey(jobName, jobGroup));
    }

    /**
     * 检查触发器是否存在
     */
    public boolean triggerExists(String triggerName, String triggerGroup) throws SchedulerException {
        return scheduler.checkExists(new TriggerKey(triggerName, triggerGroup));
    }

    /**
     * 获取作业状态
     */
    public String getJobStatus(String jobName, String jobGroup) throws SchedulerException {
        JobKey jobKey = new JobKey(jobName, jobGroup);
        if (!scheduler.checkExists(jobKey)) {
            return "NOT_FOUND";
        }

        List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
        if (triggers != null && !triggers.isEmpty()) {
            Trigger.TriggerState state = scheduler.getTriggerState(triggers.get(0).getKey());
            return state.name();
        }

        return "UNKNOWN";
    }

    /**
     * 获取作业执行次数
     */
    public int getJobExecutionCount(String jobName, String jobGroup) throws SchedulerException {
        JobKey jobKey = new JobKey(jobName, jobGroup);
        if (!scheduler.checkExists(jobKey)) {
            return 0;
        }

        JobDetail jobDetail = scheduler.getJobDetail(jobKey);
        JobDataMap dataMap = jobDetail.getJobDataMap();

        if (dataMap.containsKey("totalRuns")) {
            return dataMap.getInt("totalRuns");
        }

        return 0;
    }

    /**
     * 获取作业下次执行时间
     */
    public Date getNextFireTime(String jobName, String jobGroup) throws SchedulerException {
        JobKey jobKey = new JobKey(jobName, jobGroup);
        if (!scheduler.checkExists(jobKey)) {
            return null;
        }

        List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
        if (triggers != null && !triggers.isEmpty()) {
            return triggers.get(0).getNextFireTime();
        }

        return null;
    }

    /**
     * 获取未来几次执行时间
     */
    public List<Date> getNextFireTimes(String jobName, String jobGroup, int count) throws SchedulerException {
        List<Date> nextFireTimes = new ArrayList<>();

        JobKey jobKey = new JobKey(jobName, jobGroup);
        if (!scheduler.checkExists(jobKey)) {
            return nextFireTimes;
        }

        List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);
        if (triggers == null || triggers.isEmpty()) {
            return nextFireTimes;
        }

        Trigger trigger = triggers.get(0);
        Date nextFireTime = trigger.getNextFireTime();

        // 对于CronTrigger，可以预测未来的执行时间
        if (trigger instanceof CronTrigger) {
            CronTrigger cronTrigger = (CronTrigger) trigger;
            Date currentTime = nextFireTime != null ? nextFireTime : new Date();

            for (int i = 0; i < count; i++) {
                currentTime = cronTrigger.getFireTimeAfter(currentTime);
                if (currentTime != null) {
                    nextFireTimes.add(currentTime);
                } else {
                    break;
                }
            }
        }
        // 对于SimpleTrigger，根据重复次数和间隔计算
        else if (trigger instanceof SimpleTrigger) {
            SimpleTrigger simpleTrigger = (SimpleTrigger) trigger;
            Date currentTime = nextFireTime;

            // 只有当下次执行时间不为空，且当前列表长度小于请求数量时才继续
            while (currentTime != null && nextFireTimes.size() < count) {
                nextFireTimes.add(currentTime);

                long interval = simpleTrigger.getRepeatInterval();
                int remainingCount = simpleTrigger.getTimesTriggered();
                int maxCount = simpleTrigger.getRepeatCount();

                // 检查是否已达到最大重复次数
                if (maxCount != SimpleTrigger.REPEAT_INDEFINITELY && remainingCount >= maxCount) {
                    break;
                }

                // 计算下一次执行时间
                currentTime = new Date(currentTime.getTime() + interval);
            }
        }

        return nextFireTimes;
    }

    /**
     * 创建作业执行历史记录（可用于监控）
     */
    public void recordJobExecution(String jobName, String jobGroup, boolean success, String message) {
        try {
            JobKey jobKey = new JobKey(jobName, jobGroup);
            if (!scheduler.checkExists(jobKey)) {
                return;
            }

            JobDetail jobDetail = scheduler.getJobDetail(jobKey);
            JobDataMap dataMap = jobDetail.getJobDataMap();

            // 更新总执行次数
            int totalRuns = dataMap.containsKey("totalRuns") ? dataMap.getInt("totalRuns") + 1 : 1;
            dataMap.put("totalRuns", totalRuns);

            // 更新成功次数
            if (success) {
                int successCount = dataMap.containsKey("successCount") ? dataMap.getInt("successCount") + 1 : 1;
                dataMap.put("successCount", successCount);
            } else {
                int failureCount = dataMap.containsKey("failureCount") ? dataMap.getInt("failureCount") + 1 : 1;
                dataMap.put("failureCount", failureCount);
                // 记录最后一次失败信息
                dataMap.put("lastFailureMessage", message);
                dataMap.put("lastFailureTime", new Date());
            }

            // 更新最后执行时间
            dataMap.put("lastExecutionTime", new Date());

            // 更新作业数据
            JobBuilder jobBuilder = jobDetail.getJobBuilder();
            JobDetail updatedJobDetail = jobBuilder.usingJobData(dataMap).build();
            scheduler.addJob(updatedJobDetail, true);

        } catch (SchedulerException e) {
            // 只记录日志，不抛出异常，以避免影响正常的作业执行
            System.err.println("Error recording job execution: " + e.getMessage());
        }
    }

    /**
     * 生成唯一的作业名称
     */
    public String generateUniqueJobName(String prefix) {
        return prefix + "_" + System.currentTimeMillis();
    }

    /**
     * 从JobDataMap中提取并返回特定数据
     */
    public Map<String, Object> extractJobData(String jobName, String jobGroup) throws SchedulerException {
        JobKey jobKey = new JobKey(jobName, jobGroup);
        if (!scheduler.checkExists(jobKey)) {
            return null;
        }

        JobDetail jobDetail = scheduler.getJobDetail(jobKey);
        JobDataMap dataMap = jobDetail.getJobDataMap();

        return dataMap.getWrappedMap();
    }

    /**
     * 判断作业是否正在运行
     */
    public boolean isJobRunning(String jobName, String jobGroup) throws SchedulerException {
        List<JobExecutionContext> currentJobs = scheduler.getCurrentlyExecutingJobs();
        JobKey jobKey = new JobKey(jobName, jobGroup);

        for (JobExecutionContext context : currentJobs) {
            if (context.getJobDetail().getKey().equals(jobKey)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 获取当前正在运行的所有作业
     */
    public List<String> getCurrentlyRunningJobs() throws SchedulerException {
        List<String> runningJobs = new ArrayList<>();
        List<JobExecutionContext> currentJobs = scheduler.getCurrentlyExecutingJobs();

        for (JobExecutionContext context : currentJobs) {
            JobKey jobKey = context.getJobDetail().getKey();
            runningJobs.add(jobKey.getGroup() + "." + jobKey.getName());
        }

        return runningJobs;
    }
}