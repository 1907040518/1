package com.scheduler.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobResponse {
    private String jobName;
    private String jobGroup;
    private String status;
    private String message;
    private Date nextFireTime;
    private Date previousFireTime;
}