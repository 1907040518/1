package com.scheduler.service;

import org.quartz.*;
import org.quartz.impl.matchers.GroupMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.scheduler.model.JobInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class JobServiceImpl implements JobService {

    private static final Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

    @Autowired
    private Scheduler scheduler;

    @Override
    public List<JobDetail> getAllJobs() throws SchedulerException {
        List<JobDetail> jobList = new ArrayList<>();

        for (String groupName : scheduler.getJobGroupNames()) {
            Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName));
            for (JobKey jobKey : jobKeys) {
                JobDetail jobDetail = scheduler.getJobDetail(jobKey);
                if (jobDetail != null) {
                    jobList.add(jobDetail);
                }
            }
        }

        return jobList;
    }

    @Override
    public void pauseJob(String jobName, String groupName) throws SchedulerException {
        JobKey jobKey = JobKey.jobKey(jobName, groupName);
        if (scheduler.checkExists(jobKey)) {
            scheduler.pauseJob(jobKey);
            logger.info("任务已暂停: {}.{}", groupName, jobName);
        } else {
            throw new JobExecutionException("任务不存在: " + jobName);
        }
    }

    @Override
    public void resumeJob(String jobName, String groupName) throws SchedulerException {
        JobKey jobKey = JobKey.jobKey(jobName, groupName);
        if (scheduler.checkExists(jobKey)) {
            scheduler.resumeJob(jobKey);
            logger.info("任务已恢复: {}.{}", groupName, jobName);
        } else {
            throw new JobExecutionException("任务不存在: " + jobName);
        }
    }

    @Override
    public void deleteJob(String jobName, String groupName) throws SchedulerException {
        JobKey jobKey = JobKey.jobKey(jobName, groupName);
        if (scheduler.checkExists(jobKey)) {
            scheduler.deleteJob(jobKey);
            logger.info("任务已删除: {}.{}", groupName, jobName);
        } else {
            throw new JobExecutionException("任务不存在: " + jobName);
        }
    }

    @Override
    public void scheduleJob(JobDetail jobDetail, Trigger trigger) throws SchedulerException {
        if (scheduler.checkExists(jobDetail.getKey())) {
            throw new JobExecutionException("任务已存在: " + jobDetail.getKey());
        }
        scheduler.scheduleJob(jobDetail, trigger);
        logger.info("任务已调度: {}.{}",
                jobDetail.getKey().getGroup(), jobDetail.getKey().getName());
    }
    // 在JobServiceImpl实现类中添加此方法
    @Override
    public void addJob(JobInfo jobInfo) throws SchedulerException {
        try {
            // 验证任务信息
            if (jobInfo == null) {
                throw new IllegalArgumentException("JobInfo cannot be null");
            }

            // 获取JobClass
            Class<?> jobClass;
            try {
                jobClass = Class.forName(jobInfo.getJobClass());
            } catch (ClassNotFoundException e) {
                throw new JobExecutionException("Job class not found: " + jobInfo.getJobClass(), e);
            }

            // 创建JobDetail
            JobBuilder jobBuilder = JobBuilder.newJob((Class<? extends Job>) jobClass)
                    .withIdentity(jobInfo.getJobName(), jobInfo.getJobGroup())
                    .withDescription(jobInfo.getDescription());

            // 添加JobData
            if (jobInfo.getJobData() != null && !jobInfo.getJobData().isEmpty()) {
                JobDataMap jobDataMap = new JobDataMap(jobInfo.getJobData());
                jobBuilder.usingJobData(jobDataMap);
            }

            JobDetail jobDetail = jobBuilder.build();

            // 创建触发器
            Trigger trigger;
            if ("CRON".equals(jobInfo.getScheduleType())) {
                // CRON表达式触发器
                trigger = TriggerBuilder.newTrigger()
                        .withIdentity(jobInfo.getJobName() + "Trigger", jobInfo.getJobGroup())
                        .withSchedule(CronScheduleBuilder.cronSchedule(jobInfo.getCronExpression()))
                        .build();
            } else {
                // 默认简单触发器
                trigger = TriggerBuilder.newTrigger()
                        .withIdentity(jobInfo.getJobName() + "Trigger", jobInfo.getJobGroup())
                        .startNow()
                        .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                                .withIntervalInSeconds(60) // 默认60秒
                                .repeatForever())
                        .build();
            }

            // 检查任务是否已存在，如果存在则更新
            if (scheduler.checkExists(jobDetail.getKey())) {
                scheduler.deleteJob(jobDetail.getKey());
                logger.info("Existing job deleted: {}.{}", jobInfo.getJobGroup(), jobInfo.getJobName());
            }

            // 调度任务
            scheduler.scheduleJob(jobDetail, trigger);
            logger.info("Job scheduled: {}.{} with cron: {}",
                    jobInfo.getJobGroup(), jobInfo.getJobName(), jobInfo.getCronExpression());
        } catch (Exception e) {
            logger.error("Error scheduling job: ", e);
            throw new SchedulerException("Failed to schedule job: " + e.getMessage(), e);
        }
    }
}