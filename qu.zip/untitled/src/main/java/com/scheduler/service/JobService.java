package com.scheduler.service;

import com.scheduler.model.JobInfo;
import org.quartz.JobDetail;
import org.quartz.SchedulerException;
import org.quartz.Trigger;

import java.util.List;

public interface JobService {
    /**
     * 获取所有任务
     */
    List<JobDetail> getAllJobs() throws SchedulerException;

    /**
     * 暂停任务
     */
    void pauseJob(String jobName, String groupName) throws SchedulerException;

    /**
     * 恢复任务
     */
    void resumeJob(String jobName, String groupName) throws SchedulerException;

    /**
     * 删除任务
     */
    void deleteJob(String jobName, String groupName) throws SchedulerException;

    /**
     * 调度任务
     */
    void scheduleJob(JobDetail jobDetail, Trigger trigger) throws SchedulerException;
    // 在JobService接口中添加此方法
    /**
     * 添加并调度任务
     * @param jobInfo 任务信息
     */


    // 在JobServiceImpl实现类中添加此方法
    void addJob(JobInfo jobInfo) throws SchedulerException;
}